package model;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class ToExcel {

	private String xlsxDatei;
	public ToExcel(String xlsxDatei) {
		this.xlsxDatei = xlsxDatei;
	}

	@SuppressWarnings("resource")
	public void toExcel(ArrayList<String[]> infos) {

		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet = wb.createSheet("sheet1");
		sheet.setColumnWidth(0, 7000);
		HSSFRow row = sheet.createRow(0);

		row.createCell(0).setCellValue("Kopf");
		row.createCell(1).setCellValue("Fehlerhaft");
		row.createCell(2).setCellValue("Fehler");
		row.createCell(3).setCellValue("Warning");

		
		for (int i = 0; i< infos.size() -1; i++ ) {
			row = sheet.createRow(i+1);
			row.createCell(0).setCellValue(infos.get(i+1)[0]);
			row.createCell(1).setCellValue(infos.get(i+1)[1]);
			row.createCell(2).setCellValue(infos.get(i+1)[2]);
			row.createCell(3).setCellValue(infos.get(i+1)[3]);
		} 
		

		try {
			FileOutputStream output = new FileOutputStream(xlsxDatei);
			wb.write(output);
			output.flush();
			output.close();
			System.out.println("Success!");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Error");
		}

	}

}