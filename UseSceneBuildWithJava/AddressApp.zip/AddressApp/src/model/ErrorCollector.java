package model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;

public class ErrorCollector {

	
	private String ergDatei;
	private String xlsxDatei;
	
	public ErrorCollector(String ergDatei, String xlsxDatei){
		this.ergDatei = ergDatei;
		this.xlsxDatei = xlsxDatei;
	}
	
	public void export() {
		Charset cs = Charset.forName("UTF-8");
		try {
			readUsingBufferedReader(this.ergDatei, cs);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void readUsingBufferedReader(String fileName, Charset cs) throws IOException {
		File file = new File(fileName);
		FileInputStream fis = new FileInputStream(file);
		InputStreamReader isr = new InputStreamReader(fis, cs);
		BufferedReader br = new BufferedReader(isr);
		String line;
		System.out.println("Read text file using InputStreamReader");
		ArrayList<String[]> infos = new ArrayList<String[]>();
		String[] info = new String[4];
		String kopf = "";
		while ((line = br.readLine()) != null) {
			if (line.contains("1 +PROG")) {
				infos.add(info);
				info = new String[4];
				info[1] = "0";
				info[2] = "0";
				info[3] = "0";
			}
			if (line.contains("4 KOPF")) {
				kopf = line;
				info[0] = kopf.trim();
			}
			if (line.contains("+++++")) {
				if (line.contains("FEHLER") && line.contains("WARNUNGEN")) {
					getNumFromString(line,info);
					System.out.println("Fehler : " + info[2] + " Warning : " + info[3]);
					info[1] = (info[2] == "0" && info[3] == "0") ? "0" : "1";					
				}
			}
		}
		br.close();
		
		
		ToExcel excel = new ToExcel(xlsxDatei);
		excel.toExcel(infos);
	}

	public void getNumFromString(String s,String[] a) {
		int i = 2;
		while (!s.isEmpty()) {
			char c = s.charAt(0);
			if (c >= '0' && c <= '9') {
				a[i] = String.valueOf(c);
				i++;
			}
			s = s.substring(1);
		}
	}

}
