module AddressApp {
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.graphics;
	requires javafx.swing;
	requires org.apache.poi.poi;
	
	
	opens application to javafx.graphics, javafx.fxml;
	opens controller to javafx.fxml;
}
