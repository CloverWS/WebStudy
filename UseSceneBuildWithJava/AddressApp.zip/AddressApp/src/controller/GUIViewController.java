package controller;

import java.io.File;
import java.io.IOException;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.ErrorCollector;
import model.MsgBox;

public class GUIViewController extends GridPane{

	//Variables
    private Stage primaryStage;
	
	@FXML
    private Button saveButton;
	@FXML
    private Button ergButton;
	@FXML
    private Button xlsxButton;
	
	@FXML
    private TextField ergPath;
	@FXML
    private TextField xlsxPath;
	
	private String ergDatei;
	private String xlsxgDatei;

    //Constructor
    public GUIViewController(Stage primaryStage) {
    	
		FXMLLoader loader = new FXMLLoader(getClass().getResource("GUIView.fxml"));
		loader.setRoot(this);
		loader.setController(this);
		try {
			
			loader.load();
		    this.primaryStage = primaryStage;
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		
	}
    
    @FXML
    void save(ActionEvent event) {
    	saveAct();
    }
    
    void saveAct(){
    	MsgBox msgBox = new MsgBox();
    	try {
			ErrorCollector errorCollector = new ErrorCollector(this.getErgDatei(), this.getXlsxgDatei());
			errorCollector.export();
			msgBox.infoBox("export succeed!", "Ok");
			System.out.print("save Document");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			msgBox.infoBox("export error! please check if the path is wrong.", "error");
			e.printStackTrace();
		}
    }
    
    @FXML
    void ergSelect(ActionEvent event) {
    	ergSelectFile(primaryStage);
    }
    
    @FXML
    void xlsxSelect(ActionEvent event) {
    	xlsxSelectFile(primaryStage);
    }
    
    void ergSelectFile(Stage primaryStage) {
        primaryStage.setTitle("Bitte eine Erg-Dateil auswählen!");
        FileChooser fileChooser = new FileChooser();
        File selectedFile = fileChooser.showOpenDialog(primaryStage);
        if (selectedFile != null){
            this.setErgDatei(selectedFile.getPath());
            ergPath.setText(selectedFile.getPath());   
    }
    }
    
    void xlsxSelectFile(Stage primaryStage) {
        primaryStage.setTitle("Bitte eine Xslx-Dateil auswählen!");
        FileChooser fileChooser = new FileChooser();
        File selectedFile = fileChooser.showOpenDialog(primaryStage);
        if (selectedFile != null){
        		this.setXlsxgDatei(selectedFile.getPath());
                xlsxPath.setText(selectedFile.getPath()); 
        }
    }

	public String getErgDatei() {
		return ergDatei;
	}

	public void setErgDatei(String ergDatei) {
		this.ergDatei = ergDatei;
	}

	public String getXlsxgDatei() {
		return xlsxgDatei;
	}

	public void setXlsxgDatei(String xlsxgDatei) {
		this.xlsxgDatei = xlsxgDatei;
	}
    
    
    
    
}
